## Мультиселект
Заменяет обычный селект на мультиселект.

## Usage
```html
<select name="s" id="select">
    <option value="111">1text1</option>
    <option value="222">2text2</option>
    <option value="333">3text3</option>
</select>
```
```javascript
    const myMyltiSelect = new MultiSelect('select');
```